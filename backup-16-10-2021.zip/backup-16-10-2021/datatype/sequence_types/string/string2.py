str1="hello i am brijesh"
str2="hello i am using python"
print(str1[0:2]) #print first two character using slice operator
print(str1[4]) #print 4th number of character
print(str2*2)#print twice of any string
print(str1+str2)#print concatenate 


