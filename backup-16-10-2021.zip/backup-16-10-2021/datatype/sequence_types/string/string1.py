str='''hi i am string'''
str1="""hi i am string"""
print(str)
print(str1)
print(type(str1))


























