str="hi i am using python and used string data types"
print(str)
print(type(str))