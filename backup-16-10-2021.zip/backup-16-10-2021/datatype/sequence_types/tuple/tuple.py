# tuple is similar to list in many ways like list , tuple also contaon the collection of the items or data in different ways.
# tuple is a imutable we cant change the value in tuple
# tuple will store data ()
 
emp=("nimesh","rajesh","naimish",9122121221)
print(emp)
print(type(emp))