# list is a just like to simliar as array where we store a data in list using [] and store multiple data using (,)
# list is a mutable datatypes of sequesnce tyeps in python


emp=["vaishali","brijesh","meet","jayesh","kumar"]
print(emp)
print(type(emp))
print(emp[0:3])
print(emp[0:2])
print(emp+emp)
print(emp*4)