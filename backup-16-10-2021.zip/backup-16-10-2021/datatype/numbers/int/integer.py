a=50
print(a)
print(type(a))

b=48755
print(b)
print(type(b))