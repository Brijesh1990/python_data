abc=545454
print(abc)
print(type(abc))