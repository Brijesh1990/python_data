abc=545.56
name=14.56
b=665.45454545454
print(abc)
print(name)
print(type(b))