c=1+3j
print("The type of c is ",type(c))
print("c is a complex number :",isinstance(1+3j,complex))